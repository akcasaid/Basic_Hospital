package enc_package;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import cyr_package.CryptoUtil;
public class ParolaOlustur {

	 public static void main(String[] args) throws Exception {
	       
		 	CryptoUtil cryptoUtil=new CryptoUtil();
		 	System.out.println("PAROLA OLUŞTURMA");
		 	
		 	String girilen, girilen2, secenek, key;
		 	Scanner input = new Scanner(System.in);
		    
		 	System.out.println("Parola Oluşturmak İçin Gerekli Şifreyi Giriniz :");
		    key = input.nextLine();
		    
		    System.out.println("Dönüşümü Yapmak İstediğiniz Parolayı Giriniz :");
		    girilen = input.nextLine();
		    
		    System.out.println("Dönüşümü Yapmak İstediğiniz Tekrar Parolayı Giriniz :");
		    girilen2 = input.nextLine();
		    
		    if(girilen.equals(girilen2)) {
		    	
			    String olusturulan=cryptoUtil.encrypt(key, girilen);
			    //System.out.println("Oluşturulan Parolanız: "+olusturulan);
			    
			    System.out.println("Parola Oluşturulmuştur.Kopyalamak için 1'e dosyaya yazmak İçin 2'ye basınız.");
			    secenek = input.nextLine();
			    
			    if(secenek.equals("1")) {

			    	StringSelection stringSelection = new StringSelection(olusturulan);
			    	Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			    	clipboard.setContents(stringSelection, null);
			    	
			    	System.out.println("Parolayı Kopyalama İşleminiz Tamamlanmıştır.");
			    }
			    
			    else if(secenek.equals("2")) {
			    	String fileName = System.getProperty("user.home") + System.getProperty("file.separator") + "seleniumproperties" + System.getProperty("file.separator") + "selenium.properties";
			        Properties prop = new Properties();
			          
			         try {
			              prop.load(new FileInputStream(fileName));
			              prop.setProperty("PASSWORD", olusturulan);
			             // prop.setProperty("KEY", key);
			              prop.store(new FileOutputStream(fileName), null);
			              } 
			          catch (IOException ex) {
			              System.exit(1);
			          }
		        
			         System.out.println("Parolayı Yazma İşleminiz Tamamlanmıştır.");
			    }
			    else {
			    	System.out.println("Yanlış seçim yaptınız tekrar deneyiniz.");
			    }
			    
		    }
		    else {
		    	System.out.println("Girilen parolalar uyuşmamaktadır.Tekrar deneyiniz.");
		    	
		    }
		 }
}
